package com.esq.todolist;

//import ItemTouchHelper
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import java.util.ArrayList;

public class SwipeController extends ItemTouchHelper.Callback {
private ArrayList listOfTask ;
private MainTodoScreen mainTodoScreen;

    @Override
    public int getMovementFlags(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder) {
        return 0;
    }

    @Override
    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder viewHolder1) {
        return false;
    }

    @Override
    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int i) {
        mainTodoScreen = new MainTodoScreen();
        mainTodoScreen.listOfTask.remove(viewHolder.getAdapterPosition());
        mainTodoScreen.adapter.notifyDataSetChanged();
    }
}
